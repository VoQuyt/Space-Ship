#pragma once
class Base
{
public:
	Base();
	~Base();
};

