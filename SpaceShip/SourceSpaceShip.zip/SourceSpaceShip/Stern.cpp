#include "Stern.h"


Stern::Stern()
{
	this->name = "Stern";
	this->R = 50;
	this->life = 1;
}


Stern::~Stern()
{
}


void Stern::settings(Animation &a, float oldX, float oldY, float angle)
{
	this->anim = a;
	this->OldX = oldX;
	this->OldY = oldY;
	this->Angle = angle;
}
void Stern::update()
{
	OldY += 2;
}
void Stern::draw(RenderWindow &window)
{
	anim.sprite.setPosition(OldX, OldY);
	anim.sprite.setRotation(Angle + 90);
	window.draw(anim.sprite);

	CircleShape circle(R);
	circle.setFillColor(Color(255, 0, 0, 170));
	circle.setPosition(OldX, OldY);
	circle.setOrigin(R, R);
}