﻿#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Animation.h"
#include "Entity.h"
#include "Ship.h"
#include "Stern.h"
#include "Bullet.h"
#include "Rocket.h"
#include "UFO.h"
#include "Tank.h"

using namespace sf;


#include <list>
#include <iostream>
using namespace std;


bool isCollide(Entity *a, Entity *b, int R1, int R2)
{
	return (b->OldX - a->OldX)*(b->OldX - a->OldX) +
		(b->OldY - a->OldY)*(b->OldY - a->OldY) <
		(R1 + R2)*(R1 + R2);
}

float AIinPutX(int x1, int y1, int x2, int y2)
{
	int x_unit = 1, Dx = x2 - x1, Dy = y2 - y1; // Init first value
	int x = x1;
	float y = y1;
	float y_unit = 1;

	if (Dx < 0)
		x_unit = -1;
	if (Dy < 0)
		y_unit = -1;

	if (x1 == x2)   // duong thang dung
	{
		x_unit = 0;
	}
	else if (y1 == y2)  // duong ngang
	{
		y_unit = 0;
	}
	else if (x1 != x2 && y1 != y2)// duong xien
	{
		float m = (float)abs(Dy) / abs(Dx);
		x_unit = 1;
		y_unit = m;
		x = x1;
		y = y1;

		if (Dx < 0)
			x_unit = -1;        // ve x giam
		if (Dy < 0)
			y_unit = -m;        // ve y giam
	}
	return x_unit;
}

float AIinPutY(int x1, int y1, int x2, int y2)        // DDA algorithm
{
	int x_unit = 1, Dx = x2 - x1, Dy = y2 - y1;
	int x = x1;
	float y = y1;
	float y_unit = 1;

	if (Dx < 0)
		x_unit = -1;
	if (Dy < 0)
		y_unit = -1;

	if (x1 == x2)   // duong thang dung
	{
		x_unit = 0;
	}
	else if (y1 == y2)  // duong ngang
	{
		y_unit = 0;
	}
	else if (x1 != x2 && y1 != y2)// duong xien
	{
		float m = (float)abs(Dy) / abs(Dx);
		x_unit = 1;
		y_unit = m;
		x = x1;
		y = y1;

		if (Dx < 0)
			x_unit = -1;        // ve x giam
		if (Dy < 0)
			y_unit = -m;        // ve y giam
	}
	return y_unit;
}

float kc(float ax, float ay, float bx, float by)//tính khoảng cách giửa 2 điểm
{
	float kx, ky;
	kx = ax - bx;
	ky = ay - by;
	return sqrt(kx*kx + ky*ky);
}

float Angle(float ax, float ay, float bx, float by, float cx, float cy)
{
	float xAB, yAB, xAC, yAC;
	xAB = bx - ax; yAB = by - ay;
	xAC = cx - ax; yAC = cy - ay;
	float a, b;
	a = xAB*xAC + yAB*yAC;
	b = kc(ax, ay, bx, by)*kc(ax, ay, cx, cy);
	float c = acos((a / b)) * 180.0 / 3.14;
	if (cy < ay)
		return 360 - c;
	else
		return c;
}

void SetMusicEvent(sf::Music &MusicEvent, std::string File, int volume)
{
	MusicEvent.openFromFile(File);
	MusicEvent.setVolume(volume);
	MusicEvent.play();
}

//////Menu///////////////////
int Menu(RenderWindow &app, int x, int y);
int Start(RenderWindow &app);


int Menu(RenderWindow &app, int x, int y)
{

	app.setMouseCursorVisible(true);

	Texture tbackgrounp, tabout, tScore, tWin, tDeaf;
	tbackgrounp.loadFromFile("images/Menu.png");
	Sprite background(tbackgrounp);
	background.setPosition(x, y);
	tabout.loadFromFile("images/about.png");
	Sprite about(tabout);
	about.setPosition(1921 + x, 230 + y);
	/*tScore.loadFromFile("images/Score.png");
	Sprite Score(tScore);
	tWin.loadFromFile("images/thang.png");
	Sprite Win(tWin);
	Win.setPosition(0, 0);
	tDeaf.loadFromFile("images/Thua.png");
	Sprite Deaf(tDeaf);
	Deaf.setPosition(0, 0);*/

	int i = 0, click = 0;
	bool check = false;
	//Start the game loop
	while (app.isOpen())
	{
		// Process events
		sf::Event event;
		while (app.pollEvent(event))
		{
			// Close window: exit
			if (event.type == sf::Event::Closed)
				app.close();
		}
		if (event.type == Event::MouseButtonPressed)
		{
			if (event.key.code == sf::Mouse::Left)
			{
				if (Mouse::getPosition().x > 220 && Mouse::getPosition().x < 410 && Mouse::getPosition().y > 480 && Mouse::getPosition().y < 550)
				{
					Start(app);
				}
				if (Mouse::getPosition().x > 200 && Mouse::getPosition().x < 450 && Mouse::getPosition().y > 610 && Mouse::getPosition().y < 670)
				{
					check = true;
				}
				if (Mouse::getPosition().x > 240 && Mouse::getPosition().x < 400 && Mouse::getPosition().y > 740 && Mouse::getPosition().y < 820)
				{
					app.close();
				}
			}
		}

		if (check == true)
		{
			i += 4;
			if (i == 1200)
			{
				i = 1200;
				check = false;
			}
		}
		about.setPosition(1921 - i + x, 230 + y);
		app.clear();
		app.draw(background);
		//window.draw(Deaf);
		app.draw(about);
		app.display();
	}
	return 0;
}

int main()
{
	sf::RenderWindow window(sf::VideoMode(1920, 1080), "SpaceShip");

	sf::Image icon;
	icon.loadFromFile("images/icon.png");
	window.setIcon(icon.getSize().x, icon.getSize().y, icon.getPixelsPtr());

	//Start the game loop
	while (window.isOpen())
	{
		// Process events
		sf::Event event;
		while (window.pollEvent(event))
		{
			// Close window: exit
			if (event.type == sf::Event::Closed)
				window.close();
		}
		Menu(window, 0, 0);
		window.clear();
		window.display();
	}
	return 0;
}

int Start(RenderWindow &app)
{
	srand(time(0));

	//hide mouse;
	app.setMouseCursorVisible(false);

	// app(VideoMode(1920, 1080), "Asteroids!");
	app.setFramerateLimit(60);

	sf::View view; //= app.getView();
	view.setSize(1920, 1080);

	Texture tShip, tBullet_Ship, tRocket_Ship, tBlood_Ship, tIconBlood;
	tShip.loadFromFile("images/spaceship3.png");
	Animation sPlayer(tShip, 0, 0, 65, 100, 1, 0);
	Animation sPlayer_go(tShip, 65, 0, 65, 100, 1, 0.5);
	tBullet_Ship.loadFromFile("images/Bullet_Ship.png");
	Animation sBullet(tBullet_Ship, 0, 0, 20, 80, 3, 0.5);
	tRocket_Ship.loadFromFile("images/RocKet_Ship.png");
	Animation sRocket(tRocket_Ship, 0, 0, 20, 100, 3, 0.5);
	tBlood_Ship.loadFromFile("images/blood.png");
	Sprite Blood;
	Blood.setTexture(tBlood_Ship);
	tIconBlood.loadFromFile("images/Iconblood.png");
	Animation sIconBlood(tIconBlood, 0, 0, 100, 100, 8, 0.5);


	///SCORE////////////////////////SCORE///////////////
	int Score = 0;

	Font font;
	font.loadFromFile("images/arial.ttf");


	///////Background/////ICON////////
	Texture tBackground, tUI, tIconTime, tMouse, tScore, tWin, tDeaf, tbackground, tabout;
	tBackground.loadFromFile("images/background.png");
	Sprite background(tBackground);
	tUI.loadFromFile("images/UI.png");
	Sprite UI(tUI);
	tIconTime.loadFromFile("images/iconTime.png");
	Sprite iconTime_k(tIconTime);
	Sprite iconTime_r(tIconTime);
	tMouse.loadFromFile("images/mouse.png");
	Sprite IconMouse(tMouse);

	tScore.loadFromFile("images/Score.png");
	Sprite sscore(tScore);
	tWin.loadFromFile("images/thang.png");
	Sprite Win(tWin);
	tDeaf.loadFromFile("images/Thua.png");
	Sprite Deaf(tDeaf);


	////////Effect///////////////
	Texture tEffect_C, tWebSprite, DestroyShip, DestroyUFO;
	tEffect_C.loadFromFile("images/explosions/type_C.png");
	Animation sExplosion(tEffect_C, 0, 0, 256, 256, 48, 0.5);
	tWebSprite.loadFromFile("images/webspite.png");
	Animation sWebSpite(tWebSprite, 0, 0, 100, 100, 15, 0.2);
	DestroyShip.loadFromFile("images/explosions/type_B.png");
	Animation sExplosion_ship(DestroyShip, 0, 0, 192, 192, 64, 0.5);
	DestroyUFO.loadFromFile("images/explosions/type_A.png");
	Animation sExplosion_UFO(DestroyUFO, 0, 0, 51, 50, 20, 1);
	//t4.loadFromFile("images/rock.png");

	//t6.loadFromFile("images/rock_small.png");

	//////////////UFO/////////////////////
	Texture tUFO1, tUFO2, tUFO3, tUFO31, tBullet_UFO1, tBullet_UFO3;
	tUFO1.loadFromFile("images/UFO1.png");
	Animation sUFO1(tUFO1, 0, 0, 120, 120, 1, 0);
	tUFO2.loadFromFile("images/UFO2.png");
	Animation sUFO2(tUFO2, 0, 0, 120, 120, 5, 0.01);
	tUFO3.loadFromFile("images/UFO3.png");
	Animation sUFO3(tUFO3, 0, 0, 100, 120, 1, 0);
	tUFO31.loadFromFile("images/UFO31.png");
	Animation sUFO31(tUFO31, 0, 0, 50, 60, 1, 0);
	tBullet_UFO3.loadFromFile("images/Bullet_UFO3.png");
	Animation sBullet_UFO3(tBullet_UFO3, 0, 0, 50, 50, 1, 0);
	tBullet_UFO1.loadFromFile("images/Bullet_UFO1.png");
	Animation sBullet_UFO1(tBullet_UFO1, 0, 0, 30, 100, 2, 0.5);

	////////////Tank//////////////////
	Texture tTank;
	tTank.loadFromFile("images/tank1.png");
	Animation sTank(tTank, 0, 0, 160, 200, 20, 0.3);






	tShip.setSmooth(true);
	tBackground.setSmooth(true);




	//Animation sRock(t4, 0, 0, 64, 64, 16, 0.2);
	//Animation sRock_small(t6, 0, 0, 64, 64, 16, 0.2);

	//Animation sPlayer(t1, 40, 0, 40, 40, 1, 0);
	//Animation sPlayer_go(t1, 40, 40, 40, 40, 1, 0);

	//Animation sExplosion_ship(t7, 0, 0, 192, 192, 64, 0.5);


	//5760 x 3240



	sf::Music musicBackgroung, musicGun, musicUFODestroy, musicRockDestroy, musicShip, musicSpaceDestroy;
	musicUFODestroy.openFromFile("images/Sound/RockDestroy.wav");

	std::list<Entity*> entities;

	Ship *p = new Ship();
	p->settings(sPlayer, 800, 800, 20);
	entities.push_back(p);


	for (int i = 0; i < 10; i++)
	{
		UFO *a = new UFO();
		if (i % 2 == 0)
			a->settings(sUFO1, rand() % 500, rand() % 500, (rand() % 5 + 2) * 10, rand() % 360, 1, 3);
		else if (i % 3 == 0)
			a->settings(sUFO3, rand() % 500, rand() % 500, (rand() % 5 + 2) * 10, rand() % 360, 3, 3);
		else
			a->settings(sUFO2, rand() % 500, rand() % 500, (rand() % 5 + 2) * 10, rand() % 360, 2, 2);

		entities.push_back(a);
	}

	view.setCenter(p->OldX, p->OldY);

	float youngX, youngY;//line 254
	float Time_wait = 20, Frame_Tank = 20, Frame_Rocket = 10;
	bool check = true;
	bool ShowScore = false;
	bool ShowMenu = false;

	/////main loop/////
	while (app.isOpen())
	{
		Event event;

		Frame_Tank += 0.05;
		Frame_Rocket += 0.01;
		//cout << Frame_Tank << endl;


		while (app.pollEvent(event))
		{
			if (event.type == Event::Closed)
				app.close();

			if (event.type == Event::MouseButtonPressed)
			{
				if (event.key.code == sf::Mouse::Left && ShowMenu == true)
				{
					if (Mouse::getPosition().x + UI.getPosition().x > UI.getPosition().x + 850 && Mouse::getPosition().x + UI.getPosition().x < 1070 + UI.getPosition().x && Mouse::getPosition().y + UI.getPosition().y > UI.getPosition().y + 820 && Mouse::getPosition().y + UI.getPosition().y < 1000 +  UI.getPosition().y)
					{	
						Menu(app, UI.getPosition().x, UI.getPosition().y);
						//cout << "Menu" << endl;
					}

					
				}
				if (event.key.code == sf::Mouse::Left)
				{
					Bullet *c = new Bullet();
					c->settings(sBullet, p->OldX, p->OldY, p->Angle, 1);
					entities.push_back(c);
					Bullet *b = new Bullet();
					b->settings(sBullet, p->OldX + 20, p->OldY + 20, p->Angle + 3, 1);
					entities.push_back(b);
					Bullet *d = new Bullet();
					d->settings(sBullet, p->OldX - 20, p->OldY - 20, p->Angle - 3, 1);
					entities.push_back(d);

					/*for (int i = 0; i < 5; i++)
					{
						Bullet *b = new Bullet();
						b->settings(sBullet, (p->OldX - 40) + 20 * i, (p->OldY - 40) + 20 * i, (p->Angle - 6) + 3 * i, 1);
						entities.push_back(b);
					}*/



					//SetMusicEvent(musicGun, "images/Sound/plasma_shot.wav", 40);
				}

				if (event.key.code == sf::Mouse::Right)
				{
					if (Frame_Rocket >= Time_wait)
					{
						Rocket *r = new Rocket();
						r->settings(sRocket, p->OldX, p->OldY, p->Angle, 1);
						entities.push_back(r);
						Frame_Rocket = 0;
						//SetMusicEvent(musicGun, "images/Sound/plasma_shot.wav", 40);
					}
				}
			}

			if (event.type == Event::KeyPressed)
			{
				if (event.key.code == Keyboard::Left)
				{
					if (Frame_Tank >= Time_wait)
					{
						Tank *t = new Tank();
						t->settings(sTank, p->OldX, p->OldY, p->Angle);
						entities.push_back(t);
						Frame_Tank = 10;
						//SetMusicEvent(musicGun, "images/Sound/plasma_shot.wav", 40);
					}
				}
			}
		}

		app.setView(view);
		//view.setPosition(p->OldX - 960, p->OldY - 540);

		//lấy tọa độ chuột
		if (!sf::Mouse::isButtonPressed(sf::Mouse::Left))
		{
			youngX = sf::Mouse::getPosition().x; youngY = sf::Mouse::getPosition().y;
			p->Angle = Angle(W / 2, H / 2, W / 2 + 10, H / 2, youngX, youngY);
		}

		if (Keyboard::isKeyPressed(Keyboard::Up) && check == true)
		{
			p->thrust = true;
		}
		else
		{
			p->thrust = false;
		}

		p->frame_Ship += 0.1;
		if (p->frame_Ship >= p->time_Ship)
		{
			check = true;
			p->frame_Ship = 0;
		}

		view.setCenter(p->OldX, p->OldY);
		UI.setPosition(view.getCenter().x - 960, view.getCenter().y - 540);
		////update location score
		Text text(std::to_string(Score), font, 50), health(std::to_string(p->Health), font, 50);
		text.setPosition(1650 + UI.getPosition().x, 20 + UI.getPosition().y);
		text.setColor(Color::Red);
		health.setPosition(view.getCenter().x + 20, view.getCenter().y + 390);
		health.setColor(Color::Yellow);
		//////
		sscore.setPosition(UI.getPosition().x, UI.getPosition().y);
		Deaf.setPosition(UI.getPosition().x, UI.getPosition().y);
		Win.setPosition(UI.getPosition().x, UI.getPosition().y);

		IconMouse.setPosition(sf::Mouse::getPosition().x - 25 + view.getCenter().x - 960, sf::Mouse::getPosition().y - 25 + view.getCenter().y - 540);

		for (auto a : entities)
			for (auto b : entities)
			{
				if (a->name == "Tank")
				{
					//a->frame_Tank += 0.01;
					//cout << a->frame_Tank << endl;
					if (Frame_Tank >= Time_wait)
					{
						a->life = false;
						Frame_Tank = 0;
					}
					a->OldX = view.getCenter().x;;
					a->OldY = view.getCenter().y;
					a->Angle = p->Angle;
				}

				if (a->name == "Stern")
				{
					if (a->OldX <= 0 || a->OldX >= 6000 || a->OldY <= 0 || a->OldY >= 4000)
						a->life = false;
				}

				if (a->name == "Bullet")
				{
					if (a->OldX <= 0 || a->OldX >= 6000 || a->OldY <= 0 || a->OldY >= 4000)
						a->life = false;
				}

				if (a->name == "Rocket")
				{
					if (a->OldX <= 0 || a->OldX >= 6000 || a->OldY <= 0 || a->OldY >= 4000)
						a->life = false;
				}

				if (a->name == "UFO" && b->name == "Tank")
				{
					if (isCollide(a, b, a->R, b->R))
					{
						a->life = false;
						b->life = false;
					}
				}

				if (a->name == "Bullet" && b->name == "Tank")
				{
					if (a->Species == 0)
						if (isCollide(a, b, a->R, b->R))
							a->life = false;
				}

				if (a->name == "Rocket" && b->name == "Tank")
				{
					if (a->Species == 0)
						if (isCollide(a, b, a->R, b->R))
							a->life = false;
				}


				if (a->name == "UFO" && b->name == "Bullet")
				{
					if (b->Species == 1)
					{
						if (isCollide(a, b, a->R, b->R))
						{
							b->life = false;
							a->Blood--;
							if (a->Blood <= 0)
							{
								Score += 10;
								Entity *e = new Entity();
								e->settings(sExplosion, b->OldX, b->OldY, 0, 0);
								e->name = "explosion";
								entities.push_back(e);
								musicUFODestroy.setVolume(15);
								musicUFODestroy.play();
								if (a->R > 40 && a->Species == 3)
								{
									for (int i = 0; i < 4; i++)
									{
										UFO *u = new UFO();
										u->settings(sUFO31, b->OldX + rand() % 200, b->OldY + rand() % 200, 10 * (rand() % 2 + 2), 20, 0, 2);
										entities.push_back(u);
									}
								}
								if (a->Species == 1 && a->R < 40)
								{
									Stern *s = new Stern();
									s->settings(sIconBlood, a->OldX, a->OldY, -90);
									entities.push_back(s);
								}
								a->life = false;
							}
						}
					}
				}

				if (a->name == "Ship" && b->name == "Stern")
				{
					if (isCollide(a, b, a->R, b->R))
					{
						a->Blood += 2;
						if (a->Blood > 10)
							a->Blood = 10;
						b->life = false;
					}
				}


				//xử lý va chạm tàu bay của ta với UFO
				if (a->name == "Ship" && b->name == "UFO")
				{
					if (isCollide(a, b, a->R, b->R))
					{
						b->life = false;

						//ship destroy
						SetMusicEvent(musicSpaceDestroy, "images/Sound/SpaceDestroy.wav", 20);
						Entity *e = new Entity();
						e->settings(sExplosion_ship, a->OldX, a->OldY, 0, 0);
						e->name = "explosion";
						entities.push_back(e);

						p->settings(sPlayer, 800, 800, 20);
						p->Blood = 10;
						a->Health--;
						if (a->Health <= 0)
						{
							ShowScore = true;
							p->R3_Ship = 0;
							p->R = 0;
							p->R2_Ship = 0;
							p->R1_Ship = 0;
							p->Health = 0;
						}
					}

					//nếu thằng b tìm được vị trí của thằng a thì thằng b sẽ bay về phía của thằng a
					if (isCollide(a, b, a->R3_Ship, b->R3_UFO))
					{
						b->YoungX = AIinPutX(b->OldX, b->OldY, a->OldX, a->OldY);
						b->YoungY = AIinPutY(b->OldX, b->OldY, a->OldX, a->OldY);
						b->Angle = Angle(b->OldX, b->OldY, b->OldX + 10, b->OldY, a->OldX, a->OldY);

						if (isCollide(a, b, a->R1_Ship, b->R) && b->Species == 2)
						{
							b->YoungX = 0;
							b->YoungY = 0;
							b->frame_UFO += 0.1;
							if (b->frame_UFO >= b->time_UFO)
							{
								Bullet *q;
								q = new Bullet();
								q->settings(sBullet_UFO3, b->OldX, b->OldY, b->Angle, 0);
								entities.push_back(q);
								b->frame_UFO = 0;
							}
						}

						//nếu thằng a nằm trong tầm ngắm của thằng b thì thằng b đứng lại và bắn thằng a
						if (isCollide(a, b, a->R2_Ship, b->R))
						{
							b->YoungX = 0;
							b->YoungY = 0;
							b->frame_UFO += 0.05;
							if (b->frame_UFO >= b->time_UFO)
							{
								Bullet *q;
								Rocket *r;
								if (b->Species == 3 || b->Species == 2);
								{
									q = new Bullet();
									q->settings(sBullet_UFO3, b->OldX, b->OldY, b->Angle, 0);
									entities.push_back(q);
									b->frame_UFO = 3;
									SetMusicEvent(musicGun, "images/Sound/plasma_shot.wav", 30);
								}
								if (b->Species == 1)
								{
									r = new Rocket();
									r->settings(sBullet_UFO1, b->OldX, b->OldY, b->Angle, 0);
									entities.push_back(r);
									b->frame_UFO = 0;
								}
							}
						}
					}
				}


				if (a->name == "Bullet" && b->name == "Rocket")
				{
					if (a->Species == 1 && b->Species == 0)
						if (isCollide(a, b, a->R, b->R))
						{
							a->life = false;
							b->Blood--;
							if (b->Blood <= 0)
								b->life = false;
						}
				}

				if (a->name == "Ship" && b->name == "Rocket")
				{
					//destroy rocket cua ta
					if (!isCollide(a, b, a->R3_Ship, b->R))
						//if(b->Species == 1)
						b->life = false;
					//kiểm tra my ship có năm trong phạm vi của rocket dich hay ko?
					if (isCollide(b, a, b->R2_Rocket, a->R))
					{
						if (b->Species == 0)
							b->Angle = Angle(b->OldX, b->OldY, b->OldX + 10, b->OldY, a->OldX, a->OldY);
						if (isCollide(a, b, a->R, b->R))
						{
							if (b->Species == 0)
							{
								b->life = false;
								a->Blood -= 2;
								if (a->Blood <= 0)
								{
									//ship destroy

									SetMusicEvent(musicSpaceDestroy, "images/Sound/SpaceDestroy.wav", 20);
									Entity *e = new Entity();
									e->settings(sExplosion_ship, a->OldX, a->OldY, 0, 0);
									e->name = "explosion";
									entities.push_back(e);
									p->settings(sPlayer, 800, 800, 20);
									p->Blood = 10;

									a->Health--;
									if (a->Health <= 0)
									{
										ShowScore = true;
										p->R3_Ship = 0;
										p->R = 0;
										p->R2_Ship = 0;
										p->R1_Ship = 0;
										p->Health = 0;
									}
								}
							}
						}
					}
				}

				//nếu Rocket của ta tìm được và phá hủy được UFO của địch thì các UFO khác của địch trong bán kính 1000 đều bị phá hủy
				if (a->name == "UFO" && b->name == "Rocket")
				{
					if (isCollide(a, b, a->R2_UFO, b->R))
					{
						if (b->Species == 1)
							b->Angle = Angle(b->OldX, b->OldY, b->OldX + 10, b->OldY, a->OldX, a->OldY);
						if (isCollide(a, b, a->R, b->R))
						{
							if (b->Species == 1)
							{
								a->life = false;
								Entity *e = new Entity();
								e->settings(sExplosion, b->OldX, b->OldY, 0, 0);
								e->name = "explosion";
								entities.push_back(e);
								musicUFODestroy.setVolume(15);
								musicUFODestroy.play();
								for (auto c : entities)
								{
									if (b->name == "Rocket" && c->name == "UFO")
									{
										if (isCollide(b, c, b->R1_Rocket, c->R))
										{
											Score += 10;
											c->life = false;
											Entity *e = new Entity();
											e->settings(sExplosion, c->OldX, c->OldY, 0, 0);
											e->name = "explosion";
											entities.push_back(e);
											musicUFODestroy.setVolume(15);
											musicUFODestroy.play();
										}
									}
									if (c->name == "Rocket" && b->name == "Rocket")
									{
										if (c->Species == 0)
											if (isCollide(b, c, b->R1_Rocket, c->R))
												c->life = false;
									}
								}
								b->life = false;
							}
						}
					}
				}

				if (a->name == "Ship" && b->name == "Bullet")
				{

					if (!isCollide(a, b, a->R3_Ship, b->R))
						b->life = false;
					if (b->Species == 0)
					{
						if (isCollide(a, b, a->R, b->R))
						{
							b->life = false;
							p->YoungX = 0;
							p->YoungY = 0;
							check = false;
							Entity *e = new Entity();
							e->settings(sWebSpite, a->OldX, a->OldY, a->Angle, 0);
							e->name = "explosion";
							entities.push_back(e);

							a->Blood--;
							if (a->Blood <= 0)
							{
								//ship destroy
								SetMusicEvent(musicSpaceDestroy, "images/Sound/SpaceDestroy.wav", 20);
								Entity *E = new Entity();
								E->settings(sExplosion_ship, a->OldX, a->OldY, 0, 0);
								E->name = "explosion";
								entities.push_back(E);

								p->settings(sPlayer, 800, 800, 20);
								p->Blood = 10;

								a->Health--;
								if (a->Health <= 0)
								{
									ShowScore = true;
									p->R3_Ship = 0;
									p->R = 0;
									p->R2_Ship = 0;
									p->R1_Ship = 0;
									p->Health = 0;
								}
							}
						}
					}
				}
			}

		if (p->thrust)  p->anim = sPlayer_go;
		else   p->anim = sPlayer;


		for (auto e : entities)
			if (e->name == "explosion")
				if (e->anim.isEnd()) e->life = 0;

		if (rand() % 150 == 0)
		{
			UFO *a = new UFO();
			a->settings(sUFO1, rand() % 6000, 4000, (rand() % 5 + 2) * 10, 30, 1, 5);
			entities.push_back(a);
		}

		/*if (rand() % 150 == 0)
		{
		UFO *a = new UFO();
		a->settings(sUFO2, 6000, rand() % 300, (rand() % 5 + 2) * 10, 30, 2, 2);
		entities.push_back(a);
		}*/

		/*if (rand() % 150 == 0)
		{
		UFO *a = new UFO();
		a->settings(sUFO3, 6000, rand() % 1000, (rand() % 5 + 2) * 10, 30, 3, 3);
		entities.push_back(a);
		}*/

		for (auto i = entities.begin(); i != entities.end();)
		{
			Entity *e = *i;

			e->update();
			e->anim.update();

			if (e->life == false) { i = entities.erase(i); delete e; }
			else i++;
		}



		//////draw//////

		//location Time Khiên (p->oldX - 282, p->oldY - 431)
		//location Time Rocket (p->oldX + 210, p->oldY - 431)

		iconTime_k.setPosition(view.getCenter().x - 282, view.getCenter().y + 431);
		iconTime_r.setPosition(view.getCenter().x + 320, view.getCenter().y + 431);

		Blood.setTextureRect(IntRect(40 * p->Blood, 0, 40, 400));
		Blood.setPosition(view.getCenter().x - 909, view.getCenter().y - 249);

		app.clear();
		app.draw(background);

		for (auto i : entities)
			i->draw(app);

		app.draw(UI);
		app.draw(Blood);
		if (Frame_Tank < Time_wait)
			app.draw(iconTime_k);
		if (Frame_Rocket < Time_wait)
			app.draw(iconTime_r);
		app.draw(text);
		app.draw(health);
		if (ShowScore == true)
		{
			app.draw(sscore);
			app.draw(Deaf);
			text.setPosition(UI.getPosition().x + 920, UI.getPosition().y + 600);
			app.draw(text);//show điểm
			ShowMenu = true;//show menu
			check = false;//không cho ship di chuyển
			//app.setMouseCursorVisible(true);
		}
		app.draw(IconMouse);
		app.display();
	}

	return 0;
}