#include "UFO.h"



UFO::UFO()
{
	this->life = 1;
	this->name = "UFO";
	this->Blood = 5;
	this->R1_UFO = 300;
	this->R2_UFO = 800;
	this->R3_UFO = 3000;
	//this->YoungX = 0.001;
	//this->YoungY = 0.001;
	this->time_UFO = 5;
	this->frame_UFO = 0;
}


UFO::~UFO()
{
}

void UFO::settings(Animation &a, float oldX, float oldY, float radius, float angle, int species, int blood)
{
	this->anim = a;
	this->OldX = oldX;
	this->OldY = oldY;
	this->R = radius;
	this->Angle = angle;
	this->Species = species;
	this->Blood = blood;
}
void UFO::update()
{
	int v = 10;
	if (this->Species == 0)
		v = 18;
	OldX += YoungX * v;
	OldY += YoungY * v;
}
void UFO::draw(RenderWindow &window)
{
	anim.sprite.setPosition(OldX, OldY);
	anim.sprite.setRotation(Angle + 90);
	window.draw(anim.sprite);

	CircleShape circle(R);
	circle.setFillColor(Color(255, 0, 0, 170));
	circle.setPosition(OldX, OldY);
	circle.setOrigin(R, R);

	CircleShape circle1(R1_UFO);
	circle1.setFillColor(Color(255, 0, 0, 170));
	circle1.setPosition(OldX, OldY);
	circle1.setOrigin(R1_UFO, R1_UFO);

	CircleShape circle2(R2_UFO);
	circle2.setFillColor(Color(255, 0, 0, 170));
	circle2.setPosition(OldX, OldY);
	circle2.setOrigin(R2_UFO, R2_UFO);

	CircleShape circle3(R3_UFO);
	circle3.setFillColor(Color(255, 0, 0, 170));
	circle3.setPosition(OldX, OldY);
	circle3.setOrigin(R3_UFO, R3_UFO);
	//window.draw(circle);//cmt here///////////////////////////////////
}
