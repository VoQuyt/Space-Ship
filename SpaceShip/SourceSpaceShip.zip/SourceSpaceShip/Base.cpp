#include "Base.h"



Base::Base()
{
}


Base::~Base()
{
}
